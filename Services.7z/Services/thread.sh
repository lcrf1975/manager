#!/bin/bash

$1 >> $2 &
