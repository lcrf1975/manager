<?php

$Config_Version = "1.0a";

$Config_LogPath = "log/";
$Config_LogExt = ".out";
$Config_Server = "172.16.62.9";
$Config_User = "root";
$Config_Pwd = "itbr366";
$Config_DB = "manager";

$Config_CheckInterval = 15;

?>
