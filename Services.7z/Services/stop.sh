#!/bin/bash

echo Stoping...

killall -e main.php 2> /dev/null > /dev/null
