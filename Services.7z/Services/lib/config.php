<?php

$Config_LogPath = "log/";
$Config_LogExt = ".out";
$Config_DBCheckInterval = 60;
$Config_SupportMail = "";
$Config_Server = "127.0.0.1";
$Config_User = "root";
$Config_Pwd = "senha@cbol";
$Config_DB = "snmpservices";

?>
